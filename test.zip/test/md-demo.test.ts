/*
import test from 'node:test'
import { describe, it } from 'node:test'
import assert from 'node:assert/strict'

describe('top level test', () => {
  it('subtest 1', () => {
    assert.strictEqual(3, 5)
  })

  it('subtest 2', () => {
    assert.strictEqual(1, 2)
  })
})
*/